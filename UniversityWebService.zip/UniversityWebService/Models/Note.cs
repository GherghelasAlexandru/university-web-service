﻿namespace StudentWebService.Models
{
    public class Note
    {   
        public int NoteID { get; set; }

        public int StudentID { get; set; }

        public int MaterieID { get; set; }

        public int Nota { get; set; }
    }
}
