﻿namespace StudentWebService.Models
{
    public class Materie
    {
        public int MaterieID { get; set; }

        public required string Nume { get; set; }
    }
}
