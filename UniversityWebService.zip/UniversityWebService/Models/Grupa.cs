﻿namespace StudentWebService.Models
{
    public class Grupa
    {
        public int GrupaID { get; set; }

        public required string Denumire { get; set; }
    }
}
