﻿namespace StudentWebService.Models
{
    public class Oras
    {
        public int OrasID { get; set; }

        public required string Denumire { get; set;}
    }
}
